﻿using EFDBF;

CRUD cRUD = new CRUD();
cRUD.AddNewDept();
//cRUD.UpdateeDept();
//cRUD.DeleteDept();