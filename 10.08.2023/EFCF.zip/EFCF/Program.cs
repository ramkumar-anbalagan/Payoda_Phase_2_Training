﻿
using EFCF;
using EFDBF;

CRUD cRUD = new CRUD();