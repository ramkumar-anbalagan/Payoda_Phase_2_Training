﻿using EFCF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDBF
{
    internal class CRUD
    {
        public void AddNewDept()
        {
            using (var context = new EmployeeManagementContext())
            {
                var dept = new Dept()
                {
                    Deptno = 10,
                    DName = "HR"
                };
                context.Depts.Add(dept);
                context.SaveChanges();
            }
        }

        public void UpdateeDept()
        {
            var context = new EmployeeManagementContext();
            var seldept = context.Depts.FirstOrDefault(d => d.Deptno == 10);
            seldept.DName = "DEV";
            context.SaveChanges();

        }

        public void DeleteDept()
        {
            var context = new EmployeeManagementContext();
            var seldept = context.Depts.FirstOrDefault(d => d.Deptno == 10);

            context.SaveChanges();
        }


    }
}
